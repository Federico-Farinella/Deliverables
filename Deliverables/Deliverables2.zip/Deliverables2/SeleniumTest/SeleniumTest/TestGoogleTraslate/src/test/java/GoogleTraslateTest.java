import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class GoogleTraslateTest {
    @Test
    public void TestGoogleTraslate() throws Exception {
        GoogleTraduction traduct = new GoogleTraduction();
        int num = traduct.count();
        System.out.println(num);
        assertTrue(num > 3);
    }
}
